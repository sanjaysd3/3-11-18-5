package com.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class Employee {

	@Id
	@GeneratedValue
	private int empID;
	private String empName;
	private String job;
	private int mgrId;
	private Date hireDate;
	
	@OneToOne
	@JoinColumn(name="departmentId")
	private Department department;
	
	public Employee() {
		
	}
	
	public Employee(int empID, String empName, String job, int mgrId,
			Date hireDate, Department department) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.job = job;
		this.mgrId = mgrId;
		this.hireDate = hireDate;
		this.department = department;
	}

	public int getEmpID() {
		return empID;
	}

	public void setEmpID(int empID) {
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgrId() {
		return mgrId;
	}

	public void setMgrId(int mgrId) {
		this.mgrId = mgrId;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", job="
				+ job + ", mgrId=" + mgrId + ", hireDate=" + hireDate
				+ ", department=" + department + "]";
	}
		
}
