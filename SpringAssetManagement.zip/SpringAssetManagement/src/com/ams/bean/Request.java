package com.ams.bean;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="request")
public class Request {

	@Id
	@GeneratedValue
	private int requestId;
	private int quantity;
	private String status;
	private Date openDate;
	private Date closeDate;
	private int empId;
	private int assetId;
	
	public Request() {
		
	}

	public Request(int quantity, String status, Date openDate, Date closeDate,
			int empId, int assetId) {
		super();
		this.quantity = quantity;
		this.status = status;
		this.openDate = openDate;
		this.closeDate = closeDate;
		this.empId = empId;
		this.assetId = assetId;
	}


	public Request(int requestId, int quantity, String status, Date openDate,
			Date closeDate, int empId, int assetId) {
		super();
		this.requestId = requestId;
		this.quantity = quantity;
		this.status = status;
		this.openDate = openDate;
		this.closeDate = closeDate;
		this.empId = empId;
		this.assetId = assetId;
	}


	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public Date getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(Date closeDate) {
		this.closeDate = closeDate;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	
	
	
}
