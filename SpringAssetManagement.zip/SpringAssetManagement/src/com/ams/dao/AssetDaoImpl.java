package com.ams.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ams.bean.Asset;
import com.ams.bean.Employee;
import com.ams.bean.Request;
import com.ams.bean.UserMaster;


@Repository
@Transactional
public class AssetDaoImpl implements IAssetDao {

	@PersistenceContext
	EntityManager entity=null;

	/***************AdminModule**************************/
	@Override
	public int addAsset(Asset asset) {
		
		asset.setAssetStatus("Available");
		entity.persist(asset);
		return asset.getAssetId();
	}
	
	@Override
	public ArrayList<Asset> getAssetList() {
		Query qry=entity.createQuery("select a from Asset a");
		return (ArrayList<Asset>)qry.getResultList();
	}

	
	@Override
	public Asset getAssetDetail(int assetId) {
		
		/*String qStr = "SELECT a FROM Asset a WHERE a.assetId=:assetId"; 
		TypedQuery<Asset> query = entity.createQuery(qStr,Asset.class); 
		query.setParameter("assetId", assetId);*/
		
		Asset asset=null;
		asset=entity.find(Asset.class, assetId);
		return asset;
	}
	
	@Override
	public ArrayList<Request> getList() {
		String status="pending";
		Query qry=entity.createQuery("select s from Request s where s.status=:status");
		qry.setParameter("status", status);
		return (ArrayList<Request>)qry.getResultList();
	}
	
	@Override
	public int updateAsset(Asset asset) {
		/*Query query=entity.("update a Asset a")*/
		Asset assets=(Asset)entity.merge(asset);
		if(assets==null)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}
	
	@Override
	public void allocateRequest(int requestId, int quantity, int assetId) {
		int stat=0;
		//System.out.println(quantity);
		Asset asset=null;
		asset=entity.find(Asset.class, assetId);
		//System.out.println(asset.getAssetQuantity());
		int assetQuantity = asset.getAssetQuantity()- quantity;
		System.out.println("new quantity"+assetQuantity);
		asset.setAssetQuantity(assetQuantity);
		/*Update asset*/
		Query qry=entity.createQuery("update Asset set assetquantity=:assetQuantity where assetid=:assetId");
		qry.setParameter("assetQuantity", assetQuantity);
		qry.setParameter("assetId", assetId);
		int status1=qry.executeUpdate();
		
		/*Update request*/
		String status="Approved";
		//Request req=new Request();
		//String closeDate=null;
		//LocalDate date=LocalDate.now();
		Date date=new Date();
		//closeDate=date.toString();
		System.out.println(date);
		Query query=entity.createQuery("update Request set status=:status where requestid=:requestId");
		query.setParameter("status", status);
		query.setParameter("requestId", requestId);
		stat=query.executeUpdate();
		
		query=entity.createQuery("update Request set closedate=:date where requestid=:requestId");
		query.setParameter("date", date);
		query.setParameter("requestId", requestId);
		stat=query.executeUpdate();
		//System.out.println(asset);
		
	}
	
	
	
	
	
	/********************ManagerModule************************/
	
	@Override
	public int raiseRequest(Request request) {
		
		request.setStatus("pending");
		request.setOpenDate(new Date());
		try{
		entity.persist(request);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return request.getRequestId();
	}

	@Override
	public ArrayList<Request> viewStatus() {
		
		Query qry=entity.createQuery("select s from Request s");
		
		return (ArrayList<Request>)qry.getResultList();
	}
	
	@Override
	public ArrayList<Employee> getEmployeeList() {
		
		Query qry=entity.createQuery("select s from Employee s");
		
		return (ArrayList<Employee>)qry.getResultList();
	}
	
	
	
	/********************LoginModule*************************/
	@Override
	public UserMaster login(UserMaster user) {
		try{
			
			String uname=user.getUserName();
			String pass=user.getPassword();
			System.out.println(user.getPassword());
			String qStr = "SELECT u FROM UserMaster u WHERE u.userName=:uname and u.password=:pass"; 
			TypedQuery<UserMaster> query = entity.createQuery(qStr,UserMaster.class); 
			query.setParameter("uname", uname);
			query.setParameter("pass", pass);
			UserMaster users=null;
			
			users = query.getSingleResult();  
			return users;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}

	
	
}
